// Bir Dizi Oluşturuyouz soru sırası,soru,seçenekler, ve cevaplar
let questions = [
    {
    numb: 1,
    question: "2 4 3 4 6" +
              "-Sayılarının - verilen sayıdaki 4 rakamları-nın basamak değerleri toplamı kaçtır?",
    answer: "4040",
    options: [
      "4040",
      "444",
      "404",
      "44"
    ]
  },
    {
    numb: 2,
    question: "x ve y doğal sayılardır. x+y=20 olduğuna göre, x.y çarpımının alabileceği en büyük değer ile en küçük değerin farkı kaçtır ?",
    answer: "2",
    options: [
      "2",
      "4",
      "6",
      "8"
    ]
  },
    {
    numb: 3,
    question: "a,b ve c doğal sayılarıdır. a+bc=26 olduğuna göre,a.b.c çarpımının en büyük değeri kaçtır ?",
    answer: "3",
    options: [
      "3",
      "8",
      "12",
      "56"
    ]
  },
    {
    numb: 4,
    question: "Yüzler basamak değerleri toplamı kaçtır?",
    answer: "100",
    options: [
      "100",
      "1000",
      "10000",
      "10"
    ]
  },
    {
    numb: 5,
    question: "a bir tamsayı olmak üzere b bir basamak değeridir. a+b=10 olduğuna göre, a.b.c çarpımının en büyük değeri kaçtır ?",
    answer: "3",
    options: [
      "3",
      "8",
      "12",
      "56"
    ]
    
  },

  {
    numb: 6,
    question: "2, 8, 0, 5, 7, 1, 3 rakamları kullanılarak yazılabilecek en büyük doğal sayı aşağıdakilerden hangisidir?",
    answer: "8 753 210",
    options: [
      "8 752 301",
      "8 753 102",
      "8 753 201",
      "8 753 210"
    ]
    
  },

  {
    numb: 7,
    question: "Aşağıda verilen sayılardan hangisinde 8 sayısının basamak değeri seksen bin'dir?",
    answer: "289 427",
    options: [
      "342 087",
      "289 427",
      "864 239e",
      "308 540"
    ]
    
  },

  {
    numb: 8,
    question: "42 287 175 sayısında 287 hangi bölüktedir?",
    answer: "Binler bölüğü",
    options: [
      "Milyonlar bölüğü",
      "Birler bölüğü",
      "Onlar bölüğü",
      "Binler bölüğü"
    ]
    
  },

  {
    numb: 9,
    question: "Altı basamaklı iki doğal sayının farkı en çok kaç olur?",
    answer: "899 999",
    options: [
      "999 999",
      "999 998",
      "899 999",
      "100 000"
    ]
    
  },

  {
    numb: 10,
    question: "7, 0, 4, 1, 9 rakamlarını bir kez kullanarak oluşturulan beş basamaklı en büyük sayı ile beş basamaklı en küçük sayının toplamı kaçtır?",
    answer: "107 889",
    options: [
      "107 889",
      "106 789",
      "106 689",
      "106 698"
    ]
    
  },

  // Bu kısımdan devam ederek istediğimiz kadar soru oluşturabiliriz.
  // Soru Sıralaması Bu Şekilde Devam Etmelidir.... 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Soru",
  //   answer: "doğru cevap",
  //   options: [
  //     "cevap 1",
  //     "cevap 2",
  //     "cevap 3",
  //     "cevap 4"
  //   ]
  // },
];